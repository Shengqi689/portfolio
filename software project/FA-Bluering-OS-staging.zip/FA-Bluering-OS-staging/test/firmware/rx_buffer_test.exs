defmodule FarmbotOS.Firmware.RxBufferTest do
  use ExUnit.Case
  alias FarmbotOS.Firmware.RxBuffer
  doctest FarmbotOS.Firmware.RxBuffer, import: true
end
