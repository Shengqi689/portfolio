from template import Agent
import time, random
from Azul.azul_model import AzulGameRule as GameRule
from copy import deepcopy
from collections import deque
from queue import LifoQueue 


THINKTIME   = 0.9
NUM_PLAYERS = 2

# the following class refers from example_bfs.py
# define myAgent
class myAgent(Agent):
    # initialize attributes
    def __init__(self,_id):
        self.id = _id
        self.game_rule = GameRule(NUM_PLAYERS)

    # generate actions from the state.
    def GetActions(self, state):
        return self.game_rule.getLegalActions(state, self.id)

    # execute action from the state, return True if goal is reached, otherwise retrun false
    def DoAction(self, state, action):
        # refer from azul_utils.py
        # the fewer tiles in the floor line, the fewer points deducted
        # as a result, do not put any tile on floor line is a goal
        if action[2].num_to_floor_line==0:
            return True
        else:
            return False


    # apply Depth-first search (DFS)
    def SelectAction(self, actions, rootstate):
        start_time = time.time()
        stack = LifoQueue()
        stack = deque([(deepcopy(rootstate),[])])

        # conduct DFS starting from rootstate.
        while len(stack) and time.time()-start_time < THINKTIME:
            state, path = stack.pop() 
            new_actions = self.GetActions(state) 

            for a in new_actions: 
                next_state = deepcopy(state)              
                next_path  = path + [a]                   
                goal = self.DoAction(next_state, a) 
                if goal:
                    print("path found:", next_path)
                    return next_path[0]
                else:
                    stack.append((next_state, next_path)) 

        return random.choice(actions)