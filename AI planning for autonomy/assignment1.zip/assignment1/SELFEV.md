# Student Information

**Course:** COMP90054 AI Planning for Autonomy

**Semester:** Semester 1, 2023


**Student:**

Shengqi Ma - 1262480 - shengqim

> Replace the lines above with your correct details. Your student number should only be the **numbers**. For example: Guang Hu - 000000 - ghu1. 

**Collaborated With:**

> If you worked with another student, please include their **full name** and ask them to provide you with the **url to their github codebase**. Their codebase should be private, you will not have access to the code, so there's no issue with knowing their URL, e.g. Collaborated with: Lionel Messi - URL: github.com/what-a-worldcup.

# Self Evaluation

>**Note**
> Do not exceed 500 words for each Part. This is indicative, no need to have 500 words, and it's not a strict limit.

## Part 1
#### Self Evaluated Marks (3 marks):
3
> Please replace the above 0 with the mark you think you earned for this part. Consider how many (yours/ours) tests pass, the quality of your code, what you learnt, and [mainly for the final task] the quality of the tests that you wrote
#### Code Performance
This graph is just an example of how you can include your plots in markdown.

![Your result](img/scientific_paper_graph_quality.png)
> Please explain the code performance of your solution. You can create a video, include figures, tables, etc. Make sure to complement them with text explaining the performance.

Here are the results after running the test command:

[SearchAgent] using function ehc and heuristic manhattanHeuristic\
[SearchAgent] using problem type PositionSearchProblem\
Path found with total cost of 76 in 0.0 seconds\
Search nodes expanded: 151\
Pacman emerges victorious! Score: 434\
Average Score: 434.0\
Scores:        434.0    
Win Rate:      1/1 (1.00)\
Record:        Win       

From the result, I find the number of search nodes expanded is the same as the number in the solution file for test cases, and my algorithm successfully reached the goal state with a win rate of 100%.

#### Learning and Challenges
> Please include your top lessons learnt, and challenges faced.

I learned that implementing the algorithm is much harder than reading and understanding pseudo code of it. I realised that EHC has different open and closed lists than BFS and DFS, its open list has search nodes, but closed list has only states to increase efficiency. Furthermore, set has better processing speed than list when I compare them for storing closed states.

Challenges are testing and debugging the code to reach the optimal solution, and figuring out the way to return the path to the goal state.

#### Ideas That Almost Worked Well

> If you tried ideas that did not make it to the final code, please include them here and explain why they didn't make it.

#### Justification

> Please state the reason why you have assigned yourself these marks.

My algorithm passed the test and reached the goal state. I transformed my knowledge of search algorithms into playing the Pacman game. I put in lots of effort to deliver the algorithm.

#### New Tests Shared @ ED

> Tell us about your testcases and why were they useful

## Part 2
#### Self Evaluated Marks (3 marks):
0
> Please replace the above 0 with the mark you think you earned for this part. Consider how many (yours/ours) tests pass, the quality of your code, what you learnt, and [mainly for the final task] the quality of the tests that you wrote.
#### Code Performance
![Your result](img/scientific_paper_graph_quality.png)
> Please explain the code performance of your solution. You can create a video, include figures, tables, etc. Make sure to complement them with text explaining the performance.

#### Learning and Challenges
> Please include your top lessons learnt, and challenges faced.  

#### Ideas That Almost Worked Well

> If you tried ideas that did not make it to the final code, please include them here and explain why they didn't make it.

#### New Tests Shared @ ED

> Tell us about your testcases and why were they useful

#### Justification


> Please state the reason why you have assigned yourself these marks.

## Part 3
#### Self Evaluated Marks (4 marks):
0
> Please replace the above 0 with the mark you think you earned for this part. Consider how many (yours/ours) tests pass, the quality of your code, what you learnt, and [mainly for the final task] the quality of the tests that you wrote
#### Code Performance
![Your result](img/scientific_paper_graph_quality.png)
> Please explain the code performance of your solution. You can create a video, include figures, tables, etc. Make sure to complement them with text explaining the performance.

#### Learning and Challenges
> Please include your top lessons learnt, and challenges faced.  

#### Ideas That Almost Worked Well

> If you tried ideas that did not make it to the final code, please include them here and explain why they didn't make it.

#### Justification


> Please state the reason why you have assigned yourself these marks.

#### New Tests Shared @ ED

> Tell us about your testcases and why were they useful
