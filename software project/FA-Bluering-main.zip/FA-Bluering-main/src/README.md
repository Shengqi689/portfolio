# Source Code

This folder contains the source code for our project.

We have a number of repositories used for the source code of the FarmBot as it consists of different software. For Sprint 2, our code is also in [FarmBot Web Application](https://github.com/COMP90082-2023-SM1/FA-Bluering-Web-App). 

| Name | Description |
|----|----|
|[FarmBot Web Application](https://github.com/COMP90082-2023-SM1/FA-Bluering-Web-App)|A graphical user interface that allows a user to control and interact with the FarmBot|
|[Arduino Firmware](https://github.com/COMP90082-2023-SM1/FA-Bluering-Arduino)|This software is responsible for receiving G-Codes from the Raspberry Pi, executing them, and reporting back the results.|
|[FarmBot OS](https://github.com/COMP90082-2023-SM1/FA-Bluering-OS)|This software is responsible for communicating from the Raspberry Pi to the FarmBot Web application.|