class EnoseReadingSerializer < ApplicationSerializer
    attributes :mq3, 
               :mq4,
               :mq7,
               :mq8,
               :mq135,
               :mq136,
               :mq137,
               :mq138,
               :mg811,
               :humidity,
               :temperature,
               :x,
               :y,
               :z,
               :time_taken
end
  