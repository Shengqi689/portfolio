############################################ Custom Abstract Controller #########################################
# Used for enose_csvs_controller which takes a csv file in a post request 
# Required as we cannot inherit from the abstract controller as it doesn't allow non json api requests
# Better practice would be to change the abstract controller, but Farmbot may update source code in future, so we 
# don't want to overwrite our changes. 

module Api
    # A controller that contains all of the helper methods and shared logic for
    # all API endpoints.
    class CustomAbstractController < ApplicationController
        REQ_ID = "X-Farmbot-Rpc-Id"

        def set_default_stuff
          request.format = "json"
          id = request.headers[REQ_ID] || SecureRandom.uuid
          response.headers[REQ_ID] = id
          # IMPORTANT: We need to hoist X-Farmbot-Rpc-Id to a global so that it is
          #            accessible for use with auto sync.
          Transport.current.set_current_request_id(response.headers[REQ_ID])
        end
    
        # Disable cookies. This is an API!
        def skip_set_cookies_header
          reset_session
        end
    
        def authenticate_user!
          # All possible information that could be needed for any of the 3 auth
          # strategies.
          context = { jwt: request.headers["Authorization"],
                      user: current_user }
          # Returns a symbol representing the appropriate auth strategy, or nil if
          # unknown.
          strategy = Auth::DetermineAuthStrategy.run!(context)
          case strategy
          when :jwt
            sign_in(Auth::FromJwt.run!(context).require_consent!)
          when :already_connected
            # Probably provided a cookie.
            # 9 times out of 10, it's a unit test.
            # Our cookie system works, we just don't use it.
            current_user.require_consent!
            return true
          else
            auth_err
          end
          mark_as_seen
        rescue Mutations::ValidationException => e
          raise BadAuth, { error: e.errors.message.merge(strategy: strategy) }
        end
    
        def auth_err
          sorry("You failed to authenticate with the API. Ensure that you " \
                " provide a JSON Web Token in the `Authorization:` header.", 401)
        end
    
        def sorry(msg, status = 422)
          render json: { error: msg }, status: status and return
        end
    
        TPL = "FBOS received a 422 error %s ERRORS: %s PARAMS: %s"
    
        def mutate(outcome, options = {})
          if outcome.success?
            return options.merge(json: outcome.result)
          else
            e = outcome.errors.message
            when_farmbot_os do
              puts TPL % [
                e.to_json,
                params.to_json,
                self.class.inspect,
              ]
            end
            render options.merge(json: e, status: 422) and return
          end
        end
    
        # Devices have a `last_saw_api` field to assist users with debugging.
        # We update this column every time an FBOS device talks to the API.
        def mark_as_seen(bot = (current_user && current_user.device))
          when_farmbot_os do
            if bot
              v = fbos_version
              bot.last_saw_api = Time.now
              # Do _not_ set the FBOS version to 0.0.0 if the UA header is missing.
              if v > NULL && v < NOT_FBOS
                bot.fbos_version = (v.to_s || "").first(17)
                bot.save!
              end
            end
          end
        end
        
        def is_fbos?
          FbosDetector.pretty_ua(request).include?(FbosDetector::FARMBOT_UA_STRING)
        end
    
        # Conditionally execute a block when the request was made by a FarmBot
        def when_farmbot_os
          yield if is_fbos?
        end
    end 
end 