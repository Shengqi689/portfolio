from template import Agent
import time, random
from Azul.azul_model import AzulGameRule as GameRule
from copy import deepcopy
from collections import deque
import Azul.azul_utils
import math

THINKTIME = 0.9
NUM_PLAYERS = 2
GAMMA = 0.8  # prefer shorter paths

class myAgent(Agent):
    def __init__(self, _id):
        self.id = _id
        self.game_rule = GameRule(NUM_PLAYERS)
        self.count = 0

    def GetActions(self, state, _id):
        actions = self.game_rule.getLegalActions(state, _id)
        if len(actions) == 0:
            actions = self.game_rule.getLegalActions(state, NUM_PLAYERS)
        return actions

    def DoAction(self, state, action, _id):
        return self.game_rule.generateSuccessor(state, action, _id)

    # goal state for BrFS
    def GoalState(self, action):
        if action[2].num_to_floor_line == 0:
            return True
        return False

    def GameEnds(self, state):
        for plr_state in state.agents:
            completed_rows = plr_state.GetCompletedRows()
            if completed_rows > 0:
                return True
        return False

    # the states should be converted to str, in order to be used as keys in dictionaries
    def StateToString(self, state, _id):
        return Azul.azul_utils.AgentToString(_id, state.agents[_id]) + Azul.azul_utils.BoardToString(state)

    def ActionInList(self, action, action_list):
        # since there are actions of str type, not all actions can be tested by the function ValidAction
        if isinstance(action, str):
            if action in action_list:
                return True
        else:
            if Azul.azul_utils.ValidAction(action, action_list):
                return True
        return False

    # find all actions have not yet been visited for a state
    def ActionsNotVisited(self, actions_visited_s, state_string, actions):
        if state_string in actions_visited_s:
            actions_to_be_visited = []
            for a in actions:
                if not self.ActionInList(a, actions_visited_s[state_string]):
                    actions_to_be_visited.append(a)
            return actions_to_be_visited
        else:
            return actions

    def SelectAction(self, actions, rootstate):
        for action in actions:
            if not isinstance(action, str):
                state = self.game_rule.generateSuccessor(deepcopy(rootstate), action, self.id)
                if self.game_rule.calScore(state, self.id) > self.game_rule.calScore(rootstate, self.id):
                    return action
        start_time = time.time()
        self.count += 1
        # for the first 20 selections, MCTS is not that useful, for too many steps are randomly selected
        if self.count <= 20:
            queue = deque([(deepcopy(rootstate), [])])
            while len(queue) and time.time() - start_time < THINKTIME:
                state, path = queue.popleft()
                new_actions = self.GetActions(state, self.id)
                for a in new_actions:
                    next_state = deepcopy(state)
                    next_path = path + [a]
                    goal = self.GoalState(a)
                    if goal:
                        return next_path[0]
                    else:
                        queue.append((next_state, next_path))
            default_action = random.choice(actions)
            min_floor_number = default_action[2].num_to_floor_line
            for a in actions:
                if a[2].num_to_floor_line < min_floor_number:
                    default_action = a
            return default_action

        # UCT
        else:
            # dictionaries with states (String) as keys
            v_s = dict()
            n_s = dict()
            best_action_s = dict()
            actions_visited_s = dict()
            while time.time() - start_time < THINKTIME:
                # state and action list for iteration
                state = deepcopy(rootstate)
                action_list = []
                for action in deepcopy(actions):
                    if not isinstance(action, str):
                        if action[2].num_to_floor_line == 0:
                            action_list.append(action)
                if not len(action_list):
                    default_action = random.choice(actions)
                    min_floor_number = default_action[2].num_to_floor_line
                    for a in actions:
                        if a[2].num_to_floor_line < min_floor_number:
                            default_action = a
                    return default_action
                state_string = self.StateToString(state, self.id)
                backpropagation = deque([])

                # select an action and the next state
                while len(self.ActionsNotVisited(actions_visited_s, state_string, action_list)) == 0 and time.time() - start_time < THINKTIME and not self.GameEnds(state):
                    state_string = self.StateToString(state, self.id)
                    max_value = 0
                    action_s = action_list[0]
                    for a in action_list:
                        if (state_string, action_s) in n_s:
                            nsa = n_s[(state_string, action_s)]
                            if state_string in n_s:
                                ns = n_s[state_string]
                            else:
                                ns = 0
                            value = v_s[state_string] + (2 * math.log(ns) / nsa) ** 0.5
                            if value > max_value:
                                max_value = value
                                action_s = a

                    backpropagation.append((state_string, action_s))
                    if (state_string, action_s) in n_s:
                        n_s[(state_string, action_s)] += 1
                    else:
                        n_s[(state_string, action_s)] = 1
                    # update the selected state
                    next_state = deepcopy(state)
                    next_state = self.DoAction(next_state, action_s, self.id)
                    action_list = self.GetActions(next_state, self.id)
                    state = next_state

                # expand that state
                state_string = self.StateToString(state, self.id)
                available_actions = self.ActionsNotVisited(actions_visited_s, state_string, action_list)
                if len(available_actions) == 0:
                    continue
                else:
                    random_action = random.choice(available_actions)
                if state_string in actions_visited_s:
                    actions_visited_s[state_string].append(random_action)
                else:
                    actions_visited_s[state_string] = [random_action]
                backpropagation.append((state_string, random_action))
                if (state_string, random_action) in n_s:
                    n_s[(state_string, random_action)] += 1
                else:
                    n_s[(state_string, random_action)] = 1
                # update the selected state
                next_state = deepcopy(state)
                next_state = self.DoAction(next_state, random_action, self.id)
                action_list = self.GetActions(next_state, self.id)
                state = next_state

                # simulation and calculating the total reward
                length = 0
                while not self.GameEnds(state) and time.time() - start_time < THINKTIME:
                    length += 1
                    action = random.choice(action_list)
                    # update the selected state
                    next_state = deepcopy(state)
                    next_state = self.DoAction(next_state, action, self.id)
                    action_list = self.GetActions(next_state, self.id)
                    state = next_state
                reward = self.game_rule.calScore(state, self.id)

                # backpropagation
                reward *= GAMMA ** length
                while len(backpropagation) and time.time() - start_time < THINKTIME:
                    state_string, action = backpropagation.pop()
                    if state_string in v_s:
                        if reward > v_s[state_string]:
                            v_s[state_string] = reward
                            best_action_s[state_string] = action
                        n_s[state_string] += 1
                    else:
                        v_s[state_string] = reward
                        best_action_s[state_string] = action
                        n_s[state_string] = 1
                    reward *= GAMMA

        return best_action_s[self.StateToString(rootstate, self.id)]
