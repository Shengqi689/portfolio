# FA-Bluering

## Project Overview  

| FarmBot Web Application | Link | 
| ---- | ---- |
|Deployed Website| http://115.146.94.157:3000/app/designer/enose |
|Web App Source code (Github)*|https://github.com/COMP90082-2023-SM1/FA-Bluering-Web-App |  

\* The source code of the web application is in a different repository as it is a fork of an open-source code base. It can be treated as the 'src' folder of our submission.  

The goal of this project is to integrate an electronic nose (E-nose) with a FarmBot. The [digital agriculture](https://sefs-saf.unimelb.edu.au/research/themes/digital-agriculture-food-and-wine) team at the University of Melbourne currently performs manual measurements on crops to collect gas sensor data, however, this can be time-consuming and inefficient to set up every time data is needed. Through the integration of an E-nose with a FarmBot, researchers can collect data automatically with minimal set up. 

The [FarmBot](https://farm.bot/) is an open-source computer numerical control (CNC) machine that can plant, water and monitor crops. It has a robotic 'arm' which can move in three dimensions (x, y, z), and is attachable to FarmBot tools and sensors. The FarmBot can be controlled via a [web application](https://my.farmbot.io/) that allows a user to design the layout of their farm, move the arm, and run sequences of actions such as sowing and watering a plant. Three FarmBots are currently accessible via the rooftop of the [student pavilion](https://students.unimelb.edu.au/student-life/campuses-and-facilities/student-pavilion) at the University of Melbourne.

The E-nose (low-cost electronic nose) is a sensor developed at the University of Melbourne, originally designed to assess beer quality (Viejo et al., 2020). It consists of 9 gas sensors and a humidity and temperature sensor. The E-nose can observe and measure the existence and density of Ethanol, Methane, Carbon monoxide, Hydrogen, Ammonia-Alcohol-Benzene, Hydrogen sulphide, Ammonia, Benzene-Alcohol-Ammonia, and Carbon dioxide.

**Client** : Dr Nir Lipovetzky

## Project Goal
The goal of this project is to integrate the e-nose sensor into the Farmbot and build an extension onto the original web app to control it.

Farmbot integration
1. Connect E-nose to the FarmBot Arduino Board to power the E-nose Sensor
2. Connect the E-nose sensor to FarmBot Raspberry Pi to collect data
3. Transmit sensor data to web application

Web Application Integration
1. Control via Farmbot web app
2. View e-nose sensor readings
3. Run e-nose sensor on command
4. Automate e-nose operations

Depending on the project progress, the client also has lower priority goals which will be addressed after the main goal of integrating the e-nose is complete. 

FarmBot as an educational tool
1. Demo videos and infographics targeted at students to encourage more engagement with STEM
2. Demonstration mode for the FarmBot and E-nose 

Developer extensibility 
1. Videos to explain the physical set up of the E-nose and integration with web application

## Demo
Below is short demo of the additions we made to the web application to integrate the e-nose:
![Demo of e-nose panel on web app](/docs/readme%20assets/E-nose_demo_2.gif)

## Team Members 
| Name | Roles | Email | 
| ---- | ---- | ---- |
|Shengqi Ma | Team Leader, Product Owner | shengqim@student.unimelb.edu.au |
|Xingjian Zhang | Hardware Designer | xingjian@student.unimelb.edu.au |
|Victoria Deng | Scrum Master | dengv@student.unimelb.edu.au |
|Dylan Lynton | Quality Assurance Lead | dlynton@student.unimelb.edu.au |
|Mylan Li| Recorder | mylanl@student.unimelb.edu.au |

## Coding Standards/Github Workflow 
### Commenting

We will follow the docstring commenting convention - [docstring](https://peps.python.org/pep-0257/)
Each function will have a multi-line comment inside its declaration with the following structure:

    


    Summary

            Parameters:
                    input_variable_a (type): Description
                    input_variable_b (type): Description

            Returns:
                    output_variable (type): Description



### Programming paradigms:

We will be using a combination of procedural and object-orientated programming paradigms 
Several of our features will be implemented in the form of simple scripts, which contain a minimal amount of functions. (Eg, passing commands to the sensor) 
More complicated features will have their functionality wrapped in classes (Eg, A data visualiser that handles multiple types of visualisations and basic analysis)

### Testing:

Python will be the primary development language for our contributions to the project
For this will be using [PyTest](https://docs.pytest.org/en/7.2.x/)
Every function that does anything more than a trivial operation will have a corresponding test 

### Usability testing:

Here we test the feature in it's deployed state on the Farmbot platform

Github repository link: [Github](https://github.com/COMP90082-2023-SM1/FA-Bluering)

Version control software: [SourceTree](https://www.sourcetreeapp.com/), [GitHub Desktop](https://desktop.github.com/)

## Version Control, and Merge Protocol

### Help
If you need help:
 - [w3schools](https://www.w3schools.com/git/)
 - [atlassian](https://www.atlassian.com/git/tutorials)
Please also feel free to contact our team member Dylan Lynton for assistance in these matters
Branching, Pull requesting, Merge protocols
This project will be comprised of several sprints. For each sprint, we have decided on the following branching structure:

Each Sprint will have its own branch with the naming convention "Sprint ##" eg. "Sprint 01". This will branch from main.

At the beginning of the sprint, all members will checkout this branch and run any tests that are available. (Decision on unit testing pending)

Each feature/story point/Trello task will be given its own branch, which is to be branched out from the relevant "Sprint ##" branch. 

### NAMING CONVENTION: 
**Sprint##/Username/\[feature, bug, test]/task/date(optional)**

Once the feature is implemented, it will be merged back into its parent "Sprint ##" branch. (See below for merge protocol)

At the end of the sprint, the "Sprint ##" branch will be merged back into main

### Merge protocol
Ensure you are happy with the state of your code and it is ready to be merged
Run all tests
Pull from the parent branch (eg. "Sprint 02")
Run all tests
Submit Pull Request
Once the Pull Request is approved, merge it into the parent branch
Checkout parent branch and pull
Run all tests
Move on to the next task with confidence 

## Github Repositories 
As the Farmbot has multiple software components, they were split into multiple repositories for better code seperation. Additionally, they were also forked from the existing Farmbot repositories. 

| Name | Description |
|----|----|
|[FarmBot Web Application](https://github.com/COMP90082-2023-SM1/FA-Bluering-Web-App)|A graphical user interface that allows a user to control and interact with the FarmBot|
|[Arduino Firmware](https://github.com/COMP90082-2023-SM1/FA-Bluering-Arduino)|This software is responsible for receiving G-Codes from the Raspberry Pi, executing them, and reporting back the results.|
|[FarmBot OS](https://github.com/COMP90082-2023-SM1/FA-Bluering-OS)|This software is responsible for communicating from the Raspberry Pi to the FarmBot Web application.|

## Github Folder Structure
- [Data Samples](data%20samples)    
Documents required to generate with all the data (inputs) necessary to use prototypes  
- [Documentation](docs)    
Documentation files for the FarmBot (Requirements, Use cases etc.)  
- [Prototypes](prototypes)     
Low fidelity and high fidelity 
- [Source Code](src)    
Source code for FarmBots Project 
- [Tests](tests)    
User/System tests
- [UI](ui)    
Images and files used in prototypes

## Release History 
**Sprint 1**    
Added documentation required for Sprint 1
- Project description 
- Motivation model
- User stories 
- Personas 
- Development Environment 
- Sprint Plan 
  
**Sprint 2**  
Updated documentation for Sprint 2 
- Condensed documentation into one file 
- Updated Github Readme
- Updated Sprint artefacts 
- Updated User stories 
- Added low and high fidelity files for E-nose panel
- Added data samples for the E-nose

Code changes 
- Added E-nose script 
- Updated code with frontend and backend for E-nose (changes in [Web Application Repository](https://github.com/COMP90082-2023-SM1/FA-Bluering-Web-App)) 
  
**Sprint 3**  
Updated documentation for Sprint 3
- Updated Github Readme
- Updated Sprint artifacts
- Updated User stories
- Add hardware documentation for E-nose Casing Design and E-nose Power Cable Upgrade.
- Minor restructuring of confluence hierachy
- Added technical overview diagram

Code changes
- Add E-nose script to send csv data to backend via HTTP.
- Add an alternative Raspberry Pi to run MQTT script.
- Update code in backend (changes in [Web Application Repository](https://github.com/COMP90082-2023-SM1/FA-Bluering-Web-App)) 
    1. Add RabbitMQ Queue for e-nose message.
    2. Update ruby backend by create an API which can turn csv data into e-nose reading via HTTP.
    3. Add MQTT Script to interface sensor with Farmbot
    4. Add different queue for raspberry pi to web app communication.
- Update code in frontend (changes in [Web Application Repository](https://github.com/COMP90082-2023-SM1/FA-Bluering-Web-App)) 
    1. Added a UI element to download CSV data.
    2. Added functionality to run enose button.
    3. Added functionality to stop enose button to send data to database. 
    4. Added functionality to activate calibration procedure for e-nose.
    5. Add a chart display to show the e-nose data.

**Sprint 4**  
Updated documentation for Sprint 4
- Updated GitHub README
- Added Sprint 4 artifacts
- Updated and added developer documentation pages to confluence
- Restructured confluence hierarchy

Code Changes:
- Bug fixes
