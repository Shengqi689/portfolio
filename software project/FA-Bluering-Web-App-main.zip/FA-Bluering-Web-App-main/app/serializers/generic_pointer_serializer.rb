class GenericPointerSerializer < BasePointSerializer
  attributes :radius, :discarded_at
end
