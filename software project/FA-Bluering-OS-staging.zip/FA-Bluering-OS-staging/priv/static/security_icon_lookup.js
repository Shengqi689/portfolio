var security_icon_lookup = {};
security_icon_lookup["NONE"] = "icon_none.svg";
security_icon_lookup["WPA-PSK"] = "icon_lock.svg";
security_icon_lookup["WPA-EAP"] = "icon_key.svg";
