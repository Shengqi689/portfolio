defmodule FarmbotOS.Celery.AST.FactoryTest do
  use ExUnit.Case
  doctest FarmbotOS.Celery.AST.Factory, import: true
end
