module EnoseReadings
    Destroy = CreateDestroyer.run!(resource: EnoseReading)
end
  