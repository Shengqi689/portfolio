class EnoseReading < ApplicationRecord
    belongs_to :device
end
  