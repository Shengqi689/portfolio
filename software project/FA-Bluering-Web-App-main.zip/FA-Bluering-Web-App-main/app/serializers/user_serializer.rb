class UserSerializer < ApplicationSerializer
  attributes :name, :email
end
