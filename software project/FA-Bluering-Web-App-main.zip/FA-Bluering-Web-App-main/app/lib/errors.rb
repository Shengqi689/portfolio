module Errors
  class Forbidden < StandardError; end
  class NoBot < StandardError; end
  class LegalConsent < StandardError; end
end
