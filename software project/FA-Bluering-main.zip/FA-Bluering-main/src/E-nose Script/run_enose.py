"""
Name:------------------ `Leaf P41
Created:--------------- 1/02/2019
Edited: --------------- Iris Sun
Last Edited:----------- 16/02/2019
Platafrom: ------------ Python

DESCRIPTION:
Displays visually the different gas sensor outputs and saves the data in a CSV file
"""
from datetime import datetime
from serial.tools.list_ports import comports
import csv
import serial
import sys 
import numpy as np
from datetime import datetime

print('Starting E-nose')

#Getting command line args
file_name = sys.argv[1]

############################################################################
########################## SERIAL DEFINITIONS ##############################
############################################################################

# Prompts user to set port for e-nose (double check for how it is run on web app)
# Uses the last port found as a default 
if comports(): 
    default_port = list(comports())[0].device
    # print('Available Ports on Device:')
    # for port in comports():
    #     print(port.usb_description())
    # serial_port = input("Please enter the e-nose port: ")

else:
    print('Error: No ports found on device. Please ensure the e-nose is connected.')
    sys.exit(1)

sense_data   =  serial.Serial(
    port     = default_port,
    baudrate = 9600,
    parity   = serial.PARITY_NONE,
    stopbits = serial.STOPBITS_ONE,
    bytesize = serial.EIGHTBITS
    )

# ############################################################################
# ############################## DEFINITIONS #################################
# ############################################################################

# ############################################################################
# ########################## CSV INITIALIZATION ##############################
# ############################################################################

def write_csv (input_data):
    myFile = open(file_name, 'a')
    with myFile:
        writer = csv.writer(myFile)
        writer.writerow(input_data)

# ############################################################################
# ######################## CALCULATES HUMIDITY + TEMP ########################
# ############################################################################

def get_humidity_temp(get_data): 
    humidity_hi   = get_data[0]
    humidity_lo   = get_data[1]
    temperature_hi   = get_data[2]
    temperature_lo   = get_data[3]
    temperature = round((temperature_hi * 256 + temperature_lo)*0.1)
    humidity = (humidity_hi * 256 + humidity_lo)*0.1          
    return humidity, temperature

try:
    humidity, temperature = 0, 0
    time_vol = 0

    # Flush input buffer
    sense_data.reset_input_buffer()        
    while True:
        # No input data (check if e-nose is on)
        while (sense_data.in_waiting == 0):
            pass

        # Read a '\n' terminated line
        get_data=sense_data.read(1)

        if (get_data == b'\xAA'):
            # Reading humidity and temperature
            get_data=sense_data.read(4)
            if (get_data[0] != b'\xCC'):
                humidity, temperature = get_humidity_temp(get_data)

        elif(get_data == b'\xBB'):
            # Reading gas sensor data
            get_data = sense_data.read(9)
            if (sense_data.read(1) == b'\xee'):            
                try:
                    time_vol += 0.5
                    timestamp = datetime.now().isoformat()

                    #Creating array
                    #[MQ_3_vol,MQ_4_vol,MQ_7_vol,MQ_8_vol,MQ_135_vol,MQ_136_vol,MQ_137_vol,MQ_138_vol,MG_811_vol,humidity,temperature]
                    MQ_arr = [mq * 5/255 for mq in get_data[0:9]]
                    MQ_arr.extend([humidity, temperature, timestamp])
                    print(MQ_arr)
                    write_csv(MQ_arr)

                    np.set_printoptions(precision=2,linewidth=250)
                    print(np.array(MQ_arr))
                except:
                    print('Writting csv failed')
                    raise

# Interrupt by pressing CTRL C
except KeyboardInterrupt:
    sense_data.close()
    print('E-nose script ended.')
    
    