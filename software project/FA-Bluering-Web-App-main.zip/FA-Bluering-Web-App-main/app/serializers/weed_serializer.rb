class WeedSerializer < BasePointSerializer
  attributes :radius, :discarded_at, :plant_stage
end
