# UI 

All the images created for the prototypes (icons, fonts, backgrounds... should be here. This is different from the prototypes' folders.  These are the graphical elements that goes into the prototypes)

We used the official Farmbot source code, so no additional images/icons/fonts were required. All Farmbot assets can be located in our src repository (https://github.com/COMP90082-2023-SM1/FA-Bluering-Web-App) under the public folder.
