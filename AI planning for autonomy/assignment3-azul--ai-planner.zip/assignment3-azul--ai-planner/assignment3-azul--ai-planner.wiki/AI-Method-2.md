# AI Method 2 - Monte Carlo Tree Search (MCTS) and UCT

As the second AI technique used in the project, multiple versions of MCTS algorithms are tested, among which, an improved version of UCT outperforms others. This version (the improved UCT) is used as the one of the agents submitted.

In the agent design, MCTS algorithms are used in finding the next action to execute for the agent. It is worth noting that the improved UCT is actually a combination of UCT and BrFS, the latter of which is used in selecting the first 20 actions.

The reason is, in MCTS algorithms, after expanding a node (i.e., a state as the result of executing an action), the future rewards calculated in simulation,  are based on random selections of future actions until the end of the game. So, the longer the process of simulation is, the lower the accuracy of MCTS algorithms in predicting future rewards. The test results also suggest that MCTS underperforms some blind search algorithms in initial stage of the game.

# Table of Contents
- [Governing Strategy Tree](#governing-strategy-tree)
  * [Motivation](#motivation)
  * [Application](#application)
  * [Solved challenges](#solved-challenges)
  * [Trade-offs](#trade-offs)     
     - [Advantages](#advantages)
     - [Disadvantages](#disadvantages)
  * [Future improvements](#future-improvements)

## Governing Strategy Tree  

### Motivation
The major quantifiable dimensions in this problem that have been taken in account include: (1) the overall score (i.e., the final score this agent will earn at the end of the game), (2) the score earned through the next action and (3) the score deducted through the next action.

The three dimensions cover two goals of the game strategy, which are the highest expecting final score leading to victory and a locally best action maximising the score earned for each round.

In the improved UCT, the dimension (1) is used as the reward function of UCT, the dimension (2) as a pre-selection before using UCT to generate the next action, and the dimension (3) as a filter of actions that will be used in the UCT algorithm and the goal of BrFS.

[Back to top](#table-of-contents)

### Application  
How the improved UCT is implemented in action selection can be described as following.

First, before using BrFS (for the first 20 selections) or UCT (for other selections), a pre-selection is implemented. If an action in the action list directly leads to any increase in the score, this action will be returned as the selected action, because it is simply the locally best action.

Then, for the first 20 selections, a breadth first search with the goal of making the number of tiles put in the floor line equal to zero is conducted to find the next action within the time limit of 0.9 second. If no goal state is found in the time limit, the function will simply return the action with the least floor line number.

Otherwise, from the 21st selection, the actions available for the current state are filtered, and only the actions without putting tiles in floor line are marked as possible actions. If there are no actions meeting this requirement, as before, the selecting functon will return the action with the least number of floor tiles.

After filtering, a UCT algorithm will be implemented in the filtered actions, within the think time of 0.9s. Firstly, the action leading to the state with the maximum value of the UCB formula is selected, and that state is expanded. The algorithm simulates the future actions and states after this selected states randomly until the game is ended. A final score of the simulation is calculated as the expected reward of this state. Same as before, there are no other bounds to the process of simulation, but for the think time. That is to say, the algorithm conducts simulation and backpropagation as many and deep as possible within 0.9s, in order to find the action leading to the state with the highest expecting final score.

[Back to top](#table-of-contents)

### Solved Challenges
Before the improved UCT is selected, multiple versions of MCTS are tested. For example, ε-greedy is firstly used to solve the problem of Multi-Armed Bandits. Several values of ε are tested (e.g., 0.05, 0.1, 0.4) and the performance of them are similarly worse than that of UCT.

Moreover, before implementing various improvements listed above, the performance of UCT is also worse than that of BrFS.

| Agents                  | Wins |
|-------------------------|:-----|
| Improved UCT vs. BrFS   | 65%  |
| BrFS  vs. UCT           | 70%  |
| UCT vs. MCTS (ε-greedy) | 60%  |

[Back to top](#table-of-contents)


### Trade-offs  
#### *Advantages*  
The use of BrFS in the first 20 selections speeds up the calculation, and the strategy of finding actions with direct increase in score provides a quick and good selection.

#### *Disadvantages*
Since UCT needs to store the expecting reward (i.e., V(s)), the number visited (i.e., N(s)) and the best action so far for each state, and also the number that an action has been executed in a state (i.e., N(s,a)) in dictionaries, the space complexity is sacrificed.

Though the win rate has been improved a lot compared with the basic version of MCTS, the overall win rate is still low, when competing with the agents in the Tournaments. 

[Back to top](#table-of-contents)

### Future improvements  
There are some parameters can be modified to improve the performance, such as γ that set as 0.8 and Cp that set as 0.5 in the current algorithms.

[Back to top](#table-of-contents)
