# Data Samples

Documents you need to generate with all the data (inputs) necessary to simulate/demonstrate your prototype (whatever can be provided as an input in your prototype) 

The e-nose-sample csv files are the outputs of what the E-nose script outputs when connected to the E-nose. It is provided as a reference to future teams, and is not required to run the prototype. 

The web application requires no inputs, however it does need to have the E-nose attached. 