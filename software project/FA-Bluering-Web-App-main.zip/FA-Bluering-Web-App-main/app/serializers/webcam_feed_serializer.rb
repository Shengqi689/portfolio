class WebcamFeedSerializer < ApplicationSerializer
  attributes :url, :name
end
