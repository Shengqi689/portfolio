class FarmwareInstallationSerializer < ApplicationSerializer
  attributes :url, :package, :package_error
end
