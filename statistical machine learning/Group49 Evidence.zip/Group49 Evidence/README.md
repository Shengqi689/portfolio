# Group49 Authorship classification of academic papers

## Introduction

Our Final approach are placed in the Group49_Final Approach.ipynb, which is using TF-IDF in the data preprocessing part.
It has three two parts, including data preprocessing and model architecture. DeepANN architecture is in the model architecture.
The file named Alternative.ipynb is simlar to the our final approach, but it does not include TF-IDF in the preprocessing.
You could run the code by click the CTRL-ENTER for each block in the file.

