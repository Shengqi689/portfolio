defmodule FarmbotOS.Asset.ViewTest do
  use ExUnit.Case
end
