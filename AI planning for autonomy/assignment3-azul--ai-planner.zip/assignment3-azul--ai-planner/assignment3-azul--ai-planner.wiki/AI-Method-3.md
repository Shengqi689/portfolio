# AI Method 1 - Computational Approach

Your notes about this part of the project, including acknowledgement, comments, strengths and limitations, etc.

You **do not** need to explain the algorithm. Please tell us how you used it and how you applied it in your team.

If you use greed best first search, then, you can explain about what is the problem (state space model, especially how you define the state, how your define the goal), and heuristic function (as specific as possible) that you used. 

If you use MCTS, then, you can explain about what tree policy/simulation policy you used, how many iteration did you run, what is your reward function, the depth of each simulation etc.

# Table of Contents
- [Governing Strategy Tree](#governing-strategy-tree)
  * [Motivation](#motivation)
  * [Application](#application)
  * [Solved challenges](#solved-challenges)
  * [Trade-offs](#trade-offs)     
     - [Advantages](#advantages)
     - [Disadvantages](#disadvantages)
  * [Future improvements](#future-improvements)

## Governing Strategy Tree  

### Motivation  

The motivation of this method is to build an agent
that could make decision when playing Azul game. By
the implement of Q learning, the agent could learn
from interactions with random agents or other agents
and then improve its own performance over time. Target of this
project is to build an agent making optimal decisions,
beating more agents and achieving high scores in Azul
game. 

[Back to top](#table-of-contents)

### Application  
This method is applied to play Azul game, which is 
a tile-placement game, employing Q learning approach. 
In Azul, players will select and place tiles in turns,
competing the first one to complete patterns on boards.

[Back to top](#table-of-contents)

### Solved Challenges
Firstly, the Q-learning-based agent could learn and 
improve itself by updating features when interacting
with other agents. It uses the reward scores and adjusts
 weights to improve the ability of making decision. 
Secondly, it could update weights of features. It compares
differences between Q value of current state and next state,
then adjust the weights, to help improve the algorithm 
performance. Finally, it captures various features of 
different game states to Q learning approach. Numbers
of completed pattern lines, scores, tiles and colours 
are taken into account to improve Q learning's decision 
making ability. 

[Back to top](#table-of-contents)


### Trade-offs  
#### *Advantages*  

1. Model-free learning: Q-learning is a model-free 
   reinforcement learning algorithm, it learns from 
   interactions with others and adjust its decision-
   making method to improve itself, which offers more 
   flexibility and efficiency. 
2. Concurrency: Q learning is an approach which does 
   explore the optimal decision and learn at the same
   time.

#### *Disadvantages*

1. Time-consuming: It takes time for agent to calculate
   the Q value by exploring a wide range of features of 
   states. Especially when trying to achieve high level
   performance, it would be computationally expensive. 
   When developing the select_action function, it
   always times out. To solve this issue, random choice has
   to be employed, which potentially decrease the overall
   performance. 
2. Lack of sample efficiency: Q learning approach requires
   large amount of training episodes to achieve the optimal 
   decision-making. The training process is relatively of 
   low cost-effectiveness.

[Back to top](#table-of-contents)

### Future improvements  
1. More of useful and effective features to be discovered and
   implemented to improve the algorithm.
2. Instead of learning and training starting from scratch every
   time, some meaningful factors as weights could be stored into 
   disk or buffer, and load again when starting next round, to 
   increase efficiency. 
3. It is possible that tunning parameters as learning rate, 
   discount factor, etc, would lead a better decision. More parameters
   optimization experiments could be introduced.

[Back to top](#table-of-contents)