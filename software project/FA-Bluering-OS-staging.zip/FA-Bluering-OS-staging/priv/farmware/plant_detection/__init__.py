"""Plant Detection Package.

Modules for use in `PlantDetection.py`
"""
