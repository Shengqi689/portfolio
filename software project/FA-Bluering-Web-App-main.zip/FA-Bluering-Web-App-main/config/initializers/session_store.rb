# Be sure to restart your server when you modify this file.

FarmBot::Application.config.session_store :cookie_store, key: "__farmbot_session"
