require 'json'
require 'csv'    

module Api
    class EnoseCsvsController < CustomAbstractController
      skip_before_action :verify_authenticity_token
      before_action :set_default_stuff
      before_action :authenticate_user!
      after_action :skip_set_cookies_header

      def create
        keys = ["mq3", "mq4", "mq7", "mq8", "mq135", "mq136", "mq137", "mq138", "mg811", "humidity", "temperature", "time_taken", "x", "y", "z"]
        # Reads in file, and converts line endings 
        csv_text = File.read(params[:data].path, encoding: 'ISO-8859-1:UTF-8')
        csv_text = csv_text.tr("\r", '')
        csv = CSV.parse(csv_text)

        # Goes through each row and creates a new reading (currently no x,y,z information from enose)
        csv.each do |row|
          if row.any? { |value| value.nil? || value.blank? }
            puts 'ignore array'
          else
            timestamp = row.last.to_s
            readings = row[0..-2] << timestamp << 0 << 0 << 0
            mutate EnoseReadings::Create.run(keys.zip(readings).to_h, device: current_device)
          end
        end
        render json: {} and return    
      end
    end 
end       