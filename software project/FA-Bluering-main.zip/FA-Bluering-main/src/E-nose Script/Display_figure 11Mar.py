"""
Name:------------------ `Leaf P41
Created:--------------- 1/02/2019
Edited: --------------- Iris Sun
Last Edited:----------- 16/02/2019
Platafrom: ------------ Python

DESCRIPTION:
Displays visually the different gas sensor outputs and saves the data in a CSV file
"""
import csv
import serial
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
from matplotlib.animation import FFMpegWriter


DRAWING_ON = 1

############################################################################
############################### DEFINITIONS ################################
############################################################################
time_arr = []
MQ_3_arr  = []
MQ_4_arr  = []
MQ_7_arr  = []
MQ_8_arr  = []

MQ_135_arr  = []
MQ_136_arr  = []
MQ_137_arr  = []
MQ_138_arr  = []
MG_811_arr  = []

time_arr_s = []
MQ_3_arr_s  = []
MQ_4_arr_s  = []
MQ_7_arr_s  = []
MQ_8_arr_s  = []

MQ_135_arr_s  = []
MQ_136_arr_s  = []
MQ_137_arr_s  = []
MQ_138_arr_s  = []
MG_811_arr_s  = []

humidity_arr   = []
temperature_arr   = []


############################################################################
########################## SERIAL DEFINITIONS ##############################
############################################################################

sense_data   =  serial.Serial(
    port     = 'COM6',
    baudrate = 9600,
    parity   = serial.PARITY_NONE,
    stopbits = serial.STOPBITS_ONE,
    bytesize = serial.EIGHTBITS
    )

cnt         = 0
num_sensors = 9 
first_time  = 0

############################################################################
########################## CSV INITIALIZATION ##############################
############################################################################

def write_csv (input_data):
    myFile = open('s25week4.csv', 'a')
    with myFile:
        writer = csv.writer(myFile)
        writer.writerow(input_data)

##def make_fig():
##    gs = gridspec.GridSpec(3, 3)
##    # global ax1, ax2, ax3, ax4, ax5, ax6
##    plt.ion()
##    ax1 = plt.subplot(gs[0, 0])
##    plt.grid(True, linestyle='-.')
##    ax1.plot(time_arr_s, MQ_3_arr_s, 'r.-', label='MQ3')
##    ax1.plot(time_arr_s, MQ_4_arr_s, 'b.-', label='MQ4')
##    ax1.plot(time_arr_s, MQ_7_arr_s, 'g.-', label='MQ7')
##    plt.ylabel('PPM')
##    plt.xlabel('Time(s)')
##    # plt.legend()
##    # plt.legend(loc=(0, -0.3), ncol=3)
##
##    # global ax2
##    ax2 = plt.subplot(gs[0, 1])
##    ax2.grid(True, linestyle='-.')
##    ax2.plot(time_arr_s, MQ_8_arr_s, 'c.-', label='MQ8')
##    ax2.plot(time_arr_s, MQ_135_arr_s, 'm.-', label='MQ135')
##    ax2.plot(time_arr_s, MQ_136_arr_s, 'y.-', label='MQ136')
##    # ax2.set_ymargin(10)
##    ax2.set_ylabel('PPM')
##    ax2.set_xlabel('Time(s)')
##    # ax2.legend(('MQ8', 'MQ135', 'MQ136'), loc=(0, -0.3), ncol=3)
##
##
##    # global ax3
##    ax3 = plt.subplot(gs[0, 2])
##    ax3.grid(True, linestyle='-.')
##    ax3.plot(time_arr_s, MQ_137_arr_s, 'k.-', label='MQ137')
##    ax3.plot(time_arr_s, MQ_138_arr_s, 'go-', label='MQ138')
##    ax3.plot(time_arr_s, MG_811_arr_s, 'k+-', label='MQ811')
##    ax3.set_ymargin(0.5)
##    ax3.set_ylabel('PPM')
##    ax3.set_xlabel('Time(s)')
##    # ax3.legend(('MQ137', 'MQ138', 'MG811'), loc=(0, -0.3), ncol=3)
##
##    # global ax4
##    ax4 = plt.subplot(gs[1, 0])
##    ax4.grid(True, linestyle='-.')
##    ax4.plot(time_arr, humidity_arr, 'r.-')
##    ax4.set_ymargin(0.5)
##    ax4.set_ylabel('Humidity (%)')
##    ax4.set_xlabel('Time(s)')
##
##    # global ax5
##    ax5 = plt.subplot(gs[2, 0])
##    ax5.grid(True, linestyle='-.')
##    ax5.plot(time_arr, temperature_arr, 'b.-')
##    ax5.set_ymargin(0.5)
##    ax5.set_ylabel('Temperature (C)')
##    ax5.set_xlabel('Time(s)')
##
##    # global ax6
##    ax6 = plt.subplot(gs[1:, 1:])
##    ax6.grid(True, linestyle='-.')
##    ax6.plot(time_arr, MQ_3_arr, 'r.-', time_arr, MQ_4_arr, 'b.-', time_arr, MQ_7_arr, 'g.-',
##             time_arr, MQ_8_arr, 'c.-',
##             time_arr, MQ_135_arr, 'm.-', time_arr, MQ_136_arr, 'y.-', time_arr, MQ_137_arr,
##             'k.-', time_arr, MQ_138_arr,
##             'go-', time_arr, MG_811_arr, 'k+-')
##    ax6.set_ylim(0, 5)
##    ax6.set_ylabel('PPM')
##    ax6.set_xlabel('Time(s)')
##    ax6.legend(('MQ3', 'MQ4', 'MQ7', 'MQ8', 'MQ135', 'MQ136', 'MQ137', 'MQ138', 'MG811'),loc=(0, -0.3),  ncol=5)
##
##    plt.tight_layout()
        
# class MyPanel(wx.Panel):
#     """"""
#
#     def __init__(self, parent):
#         """Constructor"""
#         wx.Panel.__init__(self, parent)
#         self.number_of_buttons = 0
#         self.frame = parent
#
#         self.mainSizer = wx.BoxSizer(wx.VERTICAL)
#         controlSizer = wx.BoxSizer(wx.HORIZONTAL)
#         self.widgetSizer = wx.BoxSizer(wx.VERTICAL)
#
#         self.addButton = wx.Button(self, label="Start")
#         # self.addButton.Bind(wx.EVT_BUTTON, self.onAddWidget)
#         controlSizer.Add(self.addButton, 1, wx.CENTER|wx.ALL, 5)
#
#         self.removeButton = wx.Button(self, label="Stop")
#         # self.removeButton.Bind(wx.EVT_BUTTON, self.onRemoveWidget)
#         controlSizer.Add(self.removeButton, 1, wx.CENTER|wx.ALL, 5)
#
#         self.mainSizer.Add(controlSizer, 0, wx.CENTER)
#         self.mainSizer.Add(self.widgetSizer, 0, wx.CENTER|wx.ALL, 10)
#
#         self.SetSizer(self.mainSizer)
#
# class MyFrame(wx.Frame):
#     """"""
#
#     def __init__(self):
#         """Constructor"""
#         wx.Frame.__init__(self, parent=None, title="E-nose Interface 1.0")
#         self.fSizer = wx.BoxSizer(wx.VERTICAL)
#         panel = MyPanel(self)
#         self.fSizer.Add(panel, 1, wx.EXPAND)
#         self.SetSizer(self.fSizer)
#         self.Fit()
#         self.Show()
#
#
# if __name__ == "__main__":
#     app = wx.App(False)
#     frame = MyFrame()
#     app.MainLoop()

try:
    # fig, axs = plt.subplots(ncols=3, nrows=3)
    # gs = plt.get_gridspec()
    # # remove the underlying axes
    # axs[1, 1].remove()
    # axs[1, 2].remove()
    # axs[2, 1].remove()
    # axs[2, 2].remove()
    # axbig = fig.add_subplot(gs[1:, 1:])

    results = 9 * '0'
    humidity   = 0
    temperature   = 0
    time_vol = 0

    sense_data.reset_input_buffer()         # flush input buffer
    while True:
        while (sense_data.in_waiting == 0):
            pass
        # data = sense_data.readline().decode('utf-8').strip()
        get_data=sense_data.read(1)  # read a '\n' terminated line
        if (get_data == b'\xAA'):
            get_data=sense_data.read(4)
            if (get_data[0] != b'\xCC'):
                humidity_hi   = get_data[0]
                humidity_lo   = get_data[1]
                temperature_hi   = get_data[2]
                temperature_lo   = get_data[3]
                temperature = round((temperature_hi * 256 + temperature_lo)*0.1)
                humidity = (humidity_hi * 256 + humidity_lo)*0.1           ## humidity %
        elif(get_data == b'\xBB'):
            get_data = sense_data.read(9)
            if (sense_data.read(1) == b'\xee'):            
                print('data finish')
                try:
                    time_vol += 0.5
                    MQ_3_vol   = get_data[0]*5/255
                    MQ_4_vol   = get_data[1]*5/255
                    MQ_7_vol   = get_data[2]*5/255
                    MQ_8_vol   = get_data[3]*5/255
                    MQ_135_vol = get_data[4]*5/255
                    MQ_136_vol = get_data[5]*5/255
                    MQ_137_vol = get_data[6]*5/255
                    MQ_138_vol = get_data[7]*5/255
                    MG_811_vol = get_data[8]*5/255
##                    sensor_vol = [MQ_3_vol,MQ_4_vol,MQ_7_vol,MQ_8_vol,MQ_135_vol,MQ_136_vol,MQ_137_vol,MQ_138_vol,MG_811_vol]
                    np.set_printoptions(precision=2,linewidth=250)
                    save_data=[MQ_3_vol,MQ_4_vol,MQ_7_vol,MQ_8_vol,MQ_135_vol,MQ_136_vol,MQ_137_vol,MQ_138_vol,MG_811_vol,humidity,temperature]
                    write_csv(save_data)
##                    np.set_printoptions(precision=4)
                    print(np.array(save_data))
                    time_arr.append(time_vol)
                    MQ_3_arr.append(MQ_3_vol)
                    MQ_4_arr.append(MQ_4_vol)
                    MQ_7_arr.append(MQ_7_vol)
                    MQ_8_arr.append(MQ_8_vol)
                    MQ_135_arr.append(MQ_135_vol)
                    MQ_136_arr.append(MQ_136_vol)
                    MQ_137_arr.append(MQ_137_vol)
                    MQ_138_arr.append(MQ_138_vol)                
                    MG_811_arr.append(MG_811_vol)
                    time_arr_s.append(time_vol)
                    MQ_3_arr_s.append(MQ_3_vol)
                    MQ_4_arr_s.append(MQ_4_vol)
                    MQ_7_arr_s.append(MQ_7_vol)
                    MQ_8_arr_s.append(MQ_8_vol)
                    MQ_135_arr_s.append(MQ_135_vol)
                    MQ_136_arr_s.append(MQ_136_vol)
                    MQ_137_arr_s.append(MQ_137_vol)
                    MQ_138_arr_s.append(MQ_138_vol)
                    MG_811_arr_s.append(MG_811_vol)
                    humidity_arr.append(humidity)
                    temperature_arr.append(temperature)

                    try:
##                        if (DRAWING_ON):
##                            make_fig()
##
##                            plt.pause(0.000001)
##                    
##                        cnt=cnt+1
                        if(cnt>500):
                            time_arr.pop(0)
                            MQ_3_arr.pop(0)
                            MQ_4_arr.pop(0)
                            MQ_7_arr.pop(0)
                            MQ_8_arr.pop(0)
                            MQ_135_arr.pop(0)
                            MQ_136_arr.pop(0)
                            MQ_137_arr.pop(0)
                            MQ_138_arr.pop(0)                    
                            MG_811_arr.pop(0)
                            humidity_arr.pop(0)
                            temperature_arr.pop(0)
                        if (cnt > 10):
                            time_arr_s.pop(0)
                            MQ_3_arr_s.pop(0)
                            MQ_4_arr_s.pop(0)
                            MQ_7_arr_s.pop(0)
                            MQ_8_arr_s.pop(0)
                            MQ_135_arr_s.pop(0)
                            MQ_136_arr_s.pop(0)
                            MQ_137_arr_s.pop(0)
                            MQ_138_arr_s.pop(0)
                            MG_811_arr_s.pop(0)


                    except:
                        raise
                except:
                    print('Writting csv failed')
                    raise


                
# Interrupt by pressing CTRL C
except KeyboardInterrupt:
    sense_data.close()
    print('Interrupted')
   



    
