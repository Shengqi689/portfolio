import paho.mqtt.client as mqtt
import time
import os
import requests
from datetime import datetime
from subprocess import Popen

#Documentation at: https://pypi.org/project/paho-mqtt/#description

filename = None

def set_filename(): 
    global filename
    filename = os.path.join(current_dir, str(datetime.today().strftime('%d-%b-%Y, %H_%M_%S')) + '.csv') 

# Makes a http request to FarmBot web application 
def send_csv(): 
    global filename
    try:
        files = {'data': open(filename, 'rb')}
        url = f'{farmbot_ip}/api/enose_csv'
        headers = {"Authorization": f"Bearer {api_token}"}
        r = requests.post(url , files=files, headers=headers)
        # Send error if not 200 HTTP Success code
        if r.status_code != 200: 
            client.publish(enose_status_topic, 'An error occured while updating data.')
        # Otherwise all good
        else: 
            client.publish(enose_status_topic, 'E-nose data updated.')
    except: 
        client.publish(enose_status_topic, 'An error occured while updating data.')

# Reading in env variables 
broker_url = os.getenv('BROKER_URL')
broker_port = int(os.getenv('BROKER_PORT'))
mqtt_username = os.getenv('MQTT_USERNAME')
mqtt_password = os.getenv('MQTT_PASSWORD')
api_username = os.getenv('API_USERNAME')
api_password = os.getenv('API_PASSWORD')


current_dir = os.path.dirname(os.path.abspath(__file__))

# Getting device id + token from farmbot api 
try: 
    farmbot_ip = f'http://{broker_url}:3000'
    body = { 
        'user':{ 
            'email': api_username,
            'password': api_password, 
        }
    }

    r = requests.request(method='POST', 
                        url= f'{farmbot_ip}/api/tokens', 
                        headers={'content-type': 'application/json'}, 
                        json = body)

    json = r.json() 
    device_id = json['token']['unencoded']['bot']
    api_token = json['token']['encoded']

except: 
    device_id = 'device_1'
    api_token = None 

# Enose topic recieves frontend commands, enose status sends status updates to frontend
enose_topic = f'bot/{device_id}/enose'
enose_status_topic = f'bot/{device_id}/enose_status'
process = None 

# MQTT Callbacks 
def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {str(rc)}")
    client.subscribe("$SYS/#")
    subscribe_topic(enose_topic)
    time.sleep(2)

def on_publish(client, userdata, mid):
    print("Status updated.")

def subscribe_topic(topic):
    client.subscribe(topic)
    print(f"Subscribed to topic: {topic}")

def on_message(client, userdata, message):
    message_decode = str(message.payload.decode("utf-8"))
    print("message received " ,message_decode)
    print("message topic=",message.topic)
    print("message qos=",message.qos)
    print("message retain flag=",message.retain)

    if message.topic == enose_topic: 
        if message_decode == "Start": 
            start_python()
        if message_decode == "Calibrate":
            start_python()
            time.sleep(28)
            stop_python()
        if message_decode == "End":
            stop_python()

# Starts process, and checks that it is still running after 2 seconds
def start_python():
    try:
        global process 

        if not api_token: 
            client.publish(enose_status_topic, 'Unable to connect to web application. Please check your internet connection.')
        else:  
            # Calls run_enose.py
            set_filename()
            script_path = os.path.join(current_dir, "run_enose.py")
            command = ["python", script_path, filename]
            process = Popen(command)
            time.sleep(1)
            if process.poll() is None: 
                client.publish(enose_status_topic, 'E-nose running.')
            elif process.returncode == 1: 
                client.publish(enose_status_topic, 'No ports found. Please check that the E-nose is connected.')
    except: 
        client.publish(enose_status_topic, 'An error has occurred.')

#Stops python code and returns OK or error message
def stop_python(): 
    try:
        global process   
        # Stops run_enose.py         
        process.terminate()

        exitcode = process.returncode
        process = None
        if exitcode is None: 
            send_csv()
        else: 
            client.publish(enose_status_topic, 'An error has occurred.')
    except: 
        client.publish(enose_status_topic, 'An error has occurred.')

client = mqtt.Client("P1") #create new instance
client.on_message = on_message 
client.on_publish = on_publish
client.on_connect = on_connect

# Set the username and password for the MQTT client
client.username_pw_set(mqtt_username, mqtt_password)

# Connect to the RabbitMQ broker
client.connect(broker_url, broker_port, keepalive=60)

# Loop forever 
client.loop_forever()

