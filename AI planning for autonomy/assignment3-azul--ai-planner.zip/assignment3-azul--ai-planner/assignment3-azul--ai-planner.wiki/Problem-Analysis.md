# Analysis of the problem

Analysis the problem

explain which are the techniques that you choose and why

## General Comments

_General comments about the project goes here_

## Comments per topic

## Offense

## Defense