require 'json'
require 'securerandom'

module Api
    class EnoseReadingsController < Api::AbstractController
      LIMIT = 100
  
      def create
        mutate EnoseReadings::Create.run(raw_json, device: current_device)
      end
  
      def index
        maybe_paginate(readings)
      end
  
      def show
        render json: reading
      end
  
      def destroy
        reading.destroy!
        render json: ""
      end
  
    # private

    def emulate_enose
      emu_reading = {
        "mq3": rand(0.0..3.0),
        "mq4": rand(0.0..4.0),
        "mq7": rand(0.0..3.0),
        "mq8": rand(0.0..1.0),
        "mq135": rand(0.0..0.5),
        "mq136": rand(0.0..6.0),
        "mq137": rand(0.0..0.2),
        "mq138": rand(0.0..0.2),
        "mg811": rand(0.0..0.2),
        "humidity": rand(0..100),
        "temperature": rand(0..45),
        "time_taken": Time.now.strftime("%Y-%m-%dT%H:%M:%S"),
        "x": rand(0..50),
        "y": rand(0..50),
        "z": rand(0..50)
      }
    
      @emulate_enose ||= emu_reading
    end

      # Will return top 100 readings 
      def readings
        @readings ||= EnoseReading
          .where(device: current_device)
          .order(time_taken: :desc)
          .limit(LIMIT)
      end
  
      def reading
        @reading ||= readings.find(params[:id])
      end
    end
  end
  