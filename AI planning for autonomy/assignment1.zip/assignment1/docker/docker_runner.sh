#!/bin/bash

source docker/docker_config

unameOut="$(uname -s)"
case "${unameOut}" in
    Linux*)     machine=Linux;;
    Darwin*)    machine=Mac;;
    CYGWIN*)    machine=Cygwin;;
    MINGW*)     machine=MinGw;;
    *)          machine="UNKNOWN:${unameOut}"
esac
echo ${machine}

current_path=(${PWD})


docker_path='/home/code'


if [ ${machine} == MinGw ]
then
    current_path=(/${PWD})
fi




res=`docker image inspect ${image_name}:${image_tag}`


if [ ${#res} == 2 ] || [ ${force_build} == 1 ]
then
    docker image rm ${image_name}:${image_tag} 
    docker build -f docker/Dockerfile -t ${image_name}:${image_tag} .

    echo ""
    echo "--------------------"
    echo "image built"
    echo "--------------------"
    echo ""
else

    echo ""
    echo "--------------------"
    echo "image exists"
    echo "--------------------"
    echo ""
fi

echo "CPU limit: ${CPU_limit}"
echo "RAM limit: ${RAM_limit}"

# please ignore the error message. This is just incase the contianer is still there
# docker container rm ${container_name}



docker_cmd="docker run -it --rm --cpus=${CPU_limit} --memory=${RAM_limit} --name ${container_name} -v ${current_path}:${docker_path} -w /${docker_path} ${image_name}:${image_tag} $*"
# echo ${current_path}
#for debugging:
# docker_cmd="docker run -it --rm --cpus=${CPU_limit} --memory=${RAM_limit} --name ${container_name} -v ${current_path}:${docker_path} -w /${docker_path} ${image_name}:${image_tag} bash"

echo $docker_cmd
eval $docker_cmd


exit
