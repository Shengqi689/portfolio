class Weed < Point
end
