module Logs
  Destroy = CreateDestroyer.run!(resource: Log)
end
