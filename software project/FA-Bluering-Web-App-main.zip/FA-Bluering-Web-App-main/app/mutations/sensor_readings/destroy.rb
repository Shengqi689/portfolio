module SensorReadings
  Destroy = CreateDestroyer.run!(resource: SensorReading)
end
