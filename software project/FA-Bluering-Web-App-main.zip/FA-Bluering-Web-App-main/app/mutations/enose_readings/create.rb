module EnoseReadings
    class Create < Mutations::Command
      required do
        model :device, class: Device
        float :mq3 
        float :mq4
        float :mq7
        float :mq8
        float :mq135
        float :mq136
        float :mq137
        float :mq138
        float :mg811 
        float :humidity
        float :temperature 
        float :x, nils: true, empty_is_nil: true
        float :y, nils: true, empty_is_nil: true
        float :z, nils: true, empty_is_nil: true
        time :time_taken
      end
  
      def execute
        EnoseReading.create!(inputs)
      end
    
    end
  end
  